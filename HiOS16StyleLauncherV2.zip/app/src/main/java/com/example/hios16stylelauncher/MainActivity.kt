package com.example.hios16stylelauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

private data class AppItem(val name: String, val icon: ImageVector)

private val apps = listOf(
    AppItem("Phone", Icons.Default.Call),
    AppItem("Messages", Icons.Default.Message),
    AppItem("Camera", Icons.Default.PhotoCamera),
    AppItem("Gallery", Icons.Default.PhotoLibrary),
    AppItem("Music", Icons.Default.MusicNote),
    AppItem("Settings", Icons.Default.Settings),
    AppItem("Files", Icons.Default.Folder),
    AppItem("Clock", Icons.Default.AccessTime),
    AppItem("Calendar", Icons.Default.CalendarMonth),
    AppItem("Contacts", Icons.Default.Contacts),
    AppItem("Calculator", Icons.Default.Calculate),
    AppItem("Browser", Icons.Default.Language)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HiOS16Launcher() }
    }
}

@Composable
fun HiOS16Launcher() {
    var showDrawer by remember { mutableStateOf(false) }
    var showControl by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F6F8))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onVerticalDrag = { _, drag ->
                        if (drag < -18) showDrawer = true
                        if (drag > 18) showControl = true
                    }
                )
            }
    ) {
        Home(page)

        // Small page dots
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            repeat(2) { i ->
                Box(Modifier.size(if (page == i) 7.dp else 5.dp)
                    .clip(CircleShape).background(if (page == i) Color.DarkGray else Color.LightGray))
            }
        }

        AnimatedVisibility(showDrawer, enter = fadeIn(), exit = fadeOut()) {
            Drawer(onClose = { showDrawer = false })
        }

        AnimatedVisibility(showControl, enter = fadeIn(), exit = fadeOut()) {
            ControlCenter(onClose = { showControl = false })
        }
    }
}

@Composable
fun Home(page: Int) {
    val now = remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now.value = Date()
            kotlinx.coroutines.delay(1000)
        }
    }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now.value)
    val date = SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(now.value)

    Column(
        Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        Text(time, fontSize = 58.sp, fontWeight = FontWeight.Light)
        Text(date, color = Color.Gray, fontSize = 15.sp)
        Spacer(Modifier.height(22.dp))

        Card(
            Modifier.fillMaxWidth().height(112.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Row(Modifier.fillMaxSize().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HiOS 16 Style", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Text("Clean • Smooth • Modern", color = Color.Gray)
                }
                Icon(Icons.Default.WbSunny, null, Modifier.size(42.dp))
            }
        }

        Spacer(Modifier.height(22.dp))

        val homeApps = if (page == 0) apps.take(6) else apps.drop(6)
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(homeApps) { item -> AppTile(item) }
        }

        Text("Swipe up for apps  •  Swipe down for Control Center",
            fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun AppTile(item: AppItem) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(66.dp).clip(RoundedCornerShape(21.dp))
                .background(Color.White).clickable { },
            contentAlignment = Alignment.Center
        ) {
            Icon(item.icon, item.name, Modifier.size(31.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(item.name, fontSize = 12.sp)
    }
}

@Composable
fun Drawer(onClose: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = Color(0xFFF5F6F8)) {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("All Apps", fontSize = 30.sp, fontWeight = FontWeight.SemiBold, Modifier.weight(1f))
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close") }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = "", onValueChange = {},
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search apps") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = RoundedCornerShape(22.dp)
            )
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(apps) { item -> AppTile(item) }
            }
        }
    }
}

@Composable
fun ControlCenter(onClose: () -> Unit) {
    var wifi by remember { mutableStateOf(true) }
    var bt by remember { mutableStateOf(false) }
    var silent by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize(), color = Color(0xFFF2F3F5)) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Control Center", fontSize = 29.sp, fontWeight = FontWeight.SemiBold, Modifier.weight(1f))
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close") }
            }
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Toggle("Wi‑Fi", Icons.Default.Wifi, wifi) { wifi = !wifi }
                Toggle("Bluetooth", Icons.Default.Bluetooth, bt) { bt = !bt }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Toggle("Silent", Icons.Default.VolumeOff, silent) { silent = !silent }
                Toggle("Flashlight", Icons.Default.FlashlightOn, false) { }
            }
            Spacer(Modifier.height(22.dp))
            Text("Brightness", fontWeight = FontWeight.Medium)
            Slider(value = 0.75f, onValueChange = {}, modifier = Modifier.fillMaxWidth())
            Text("Volume", fontWeight = FontWeight.Medium)
            Slider(value = 0.55f, onValueChange = {}, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Text("HiOS 16 Style Control Center", color = Color.Gray)
        }
    }
}

@Composable
fun Toggle(title: String, icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    Card(
        Modifier.weight(1f).height(100.dp).clickable { onClick() },
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = if (active) Color(0xFFE0E3E7) else Color.White)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center) {
            Icon(icon, null, Modifier.size(28.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, fontSize = 13.sp)
        }
    }
}
