# HiOS 16 Style Launcher V2

A standalone launcher prototype for Android that recreates a HiOS-16-inspired look without modifying Tecno firmware.

Included:
- Large clock/date home screen
- Rounded app tiles
- Built-in app drawer and search field
- Swipe-up app drawer
- Swipe-down Control Center
- Wi-Fi/Bluetooth/Silent/flashlight style toggles
- Brightness and volume sliders
- Two home pages
- No root and no firmware flashing

This is NOT official Tecno HiOS 16 and does not install Tecno system apps or firmware.
Open in Android Studio and build/install it on a compatible Android device.
