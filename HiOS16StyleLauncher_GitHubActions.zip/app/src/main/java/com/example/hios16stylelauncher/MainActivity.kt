package com.example.hios16stylelauncher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.delay

data class RealApp(val label: String, val packageName: String, val activityName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val installedApps = remember { loadApps() }
            HiOSLauncher(installedApps)
        }
    }

    private fun loadApps(): List<RealApp> {
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        return packageManager.queryIntentActivities(intent, 0)
            .map { ri: ResolveInfo ->
                RealApp(
                    ri.loadLabel(packageManager).toString(),
                    ri.activityInfo.packageName,
                    ri.activityInfo.name
                )
            }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
fun HiOSLauncher(apps: List<RealApp>) {
    var drawer by remember { mutableStateOf(false) }
    var control by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }

    Box(
        Modifier.fillMaxSize()
            .background(Color(0xFFF4F5F7))
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, drag ->
                    if (drag < -20) drawer = true
                    if (drag > 20) control = true
                }
            }
    ) {
        Home(apps, page)
        AnimatedVisibility(drawer, enter = fadeIn(), exit = fadeOut()) {
            Drawer(apps) { drawer = false }
        }
        AnimatedVisibility(control, enter = fadeIn(), exit = fadeOut()) {
            ControlCenter { control = false }
        }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 38.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            repeat(2) { i ->
                Box(Modifier.size(if (page == i) 7.dp else 5.dp)
                    .clip(CircleShape)
                    .background(if (page == i) Color.DarkGray else Color.LightGray))
            }
        }
    }
}

@Composable
fun Home(apps: List<RealApp>, page: Int) {
    var date by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { date = Date(); delay(1000) } }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
    val day = SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(date)

    val featured = listOf(
        "Phone" to Icons.Default.Call,
        "Messages" to Icons.Default.Message,
        "Camera" to Icons.Default.PhotoCamera,
        "Gallery" to Icons.Default.PhotoLibrary,
        "Settings" to Icons.Default.Settings,
        "Music" to Icons.Default.MusicNote
    )

    Column(
        Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        Text(time, fontSize = 58.sp, fontWeight = FontWeight.Light)
        Text(day, color = Color.Gray)
        Spacer(Modifier.height(20.dp))

        Card(
            Modifier.fillMaxWidth().height(112.dp),
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(Color.White)
        ) {
            Row(Modifier.fillMaxSize().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HiOS 16", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Text("Style Launcher", color = Color.Gray)
                }
                Icon(Icons.Default.WbSunny, null, Modifier.size(44.dp))
            }
        }

        Spacer(Modifier.height(22.dp))

        if (page == 0) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(featured) { (name, icon) ->
                    StaticTile(name, icon)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(apps.take(6)) { app -> RealAppTile(app) }
            }
        }

        Text("Swipe ↑ Apps   •   Swipe ↓ Control Center",
            fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
fun StaticTile(name: String, icon: ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Color.White),
            contentAlignment = Alignment.Center) {
            Icon(icon, name, Modifier.size(32.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(name, fontSize = 12.sp)
    }
}

@Composable
fun RealAppTile(app: RealApp) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Color.White),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Apps, app.label, Modifier.size(32.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(app.label, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun Drawer(apps: List<RealApp>, close: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = apps.filter { it.label.contains(query, true) }

    Surface(Modifier.fillMaxSize(), Color(0xFFF4F5F7)) {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("All Apps", 30.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = close) { Icon(Icons.Default.Close, "Close") }
            }
            OutlinedTextField(
                query, { query = it }, Modifier.fillMaxWidth(),
                placeholder = { Text("Search apps") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(22.dp)
            )
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(filtered) { app -> RealAppTile(app) }
            }
        }
    }
}

@Composable
fun ControlCenter(close: () -> Unit) {
    var wifi by remember { mutableStateOf(true) }
    var bluetooth by remember { mutableStateOf(false) }
    var silent by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(.75f) }

    Surface(Modifier.fillMaxSize(), Color(0xFFF1F2F4)) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Control Center", 29.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = close) { Icon(Icons.Default.Close, "Close") }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Toggle("Wi-Fi", Icons.Default.Wifi, wifi) { wifi = !wifi }
                Toggle("Bluetooth", Icons.Default.Bluetooth, bluetooth) { bluetooth = !bluetooth }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Toggle("Silent", Icons.Default.VolumeOff, silent) { silent = !silent }
                Toggle("Flashlight", Icons.Default.FlashlightOn, false) {}
            }
            Spacer(Modifier.height(24.dp))
            Text("Brightness", fontWeight = FontWeight.Medium)
            Slider(brightness, { brightness = it })
            Text("Quick controls are visual in this launcher.")
            Text("System settings remain controlled by Android/Tecno.",
                color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun Toggle(title: String, icon: ImageVector, active: Boolean, click: () -> Unit) {
    Card(
        Modifier.weight(1f).height(100.dp).clickable { click() },
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(if (active) Color(0xFFE0E3E7) else Color.White)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center) {
            Icon(icon, null, Modifier.size(28.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, fontSize = 13.sp)
        }
    }
}
