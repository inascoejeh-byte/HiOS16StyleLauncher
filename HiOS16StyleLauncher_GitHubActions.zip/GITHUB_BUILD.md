# Build the APK on GitHub

1. Create a new GitHub repository.
2. Upload the contents of this project (not the ZIP file itself).
3. Make sure `.github/workflows/build-apk.yml` is uploaded.
4. Push to `main` or `master`, or open Actions and run **Build Android APK** manually.
5. Open the completed workflow run.
6. Under **Artifacts**, download `HiOS16StyleLauncher-debug`.
7. Extract the APK and install it on your Android phone.

The workflow creates a debug APK. It is not an official Tecno HiOS firmware package.
