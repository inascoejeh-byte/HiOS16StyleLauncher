# HiOS 16 Style Launcher Enhanced

Unofficial HiOS-16-inspired launcher for the Tecno Spark 40 Pro.

Features:
- Large clock/date
- Rounded modern UI
- Built-in app drawer
- Searches installed launcher apps
- Two home pages
- Swipe-up drawer
- Swipe-down Control Center
- HiOS-inspired quick tiles
- No root
- No firmware flashing

Build:
1. Open this project in Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).
4. Install app/build/outputs/apk/debug/app-debug.apk.
5. Select it as the Home/default launcher.

Note: This does not install or modify official Tecno HiOS firmware.
